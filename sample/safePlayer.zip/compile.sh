ghc safePlayer.hs
