cd $(dirname $0)
filepath=`pwd`
"${filepath}"/safePlayer
